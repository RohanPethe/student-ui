# three-tier-arch-aws-terraform
Provision three tier architecture on AWS using Terraform
